function warn(warnText)
  local logfile = fs.open("filus/logs/log.txt", "a")
  --if not http.get("http://localhost:33/time").readAll() then return false end
  if not http.get("http://localhost:33/time").readAll() then
    return false;
  end
  logfile.writeLine("[Warning] ["..shell.getRunningProgram().."] ["..http.get("http://localhost:33/time").readAll().."] "..warnText)
  logfile.close()
  --fs to file [warning]
  --print("Coming Soon")
end
_G.warn = warn
